import io
import textwrap

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

st.set_page_config(page_title="PolicyPulse", layout="wide")


@st.cache_data
def load_data(uploaded_file):
    if uploaded_file is None:
        return None
    return pd.read_csv(uploaded_file)


def summarize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in df.columns:
        series = df[col]
        rows.append(
            {
                "column": col,
                "dtype": str(series.dtype),
                "missing_values": int(series.isna().sum()),
                "missing_pct": round(series.isna().mean() * 100, 2),
                "unique_values": int(series.nunique(dropna=True)),
            }
        )
    return pd.DataFrame(rows)


def detect_problem_type(series: pd.Series) -> str:
    if pd.api.types.is_numeric_dtype(series):
        unique_count = series.nunique(dropna=True)
        if unique_count <= 10:
            return "classification"
        return "regression"
    return "classification"


def build_model(X: pd.DataFrame, y: pd.Series, problem_type: str):
    numeric_features = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_features = [c for c in X.columns if c not in numeric_features]

    numeric_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ]
    )

    if problem_type == "regression":
        model = LinearRegression()
    else:
        model = LogisticRegression(max_iter=300)

    pipeline = Pipeline(
        steps=[("preprocessor", preprocessor), ("model", model)]
    )
    return pipeline


def generate_narrative(df: pd.DataFrame, target: str, problem_type: str) -> str:
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    narrative = []

    narrative.append(
        f"This dataset contains {len(df):,} rows and {len(df.columns)} columns. "
        f"The selected target variable is '{target}', so the analysis is framed as a {problem_type} task."
    )

    if numeric_cols:
        corr_text = []
        if target in numeric_cols:
            corrs = (
                df[numeric_cols]
                .corr(numeric_only=True)[target]
                .drop(labels=[target], errors="ignore")
                .dropna()
                .sort_values(key=lambda s: s.abs(), ascending=False)
                .head(3)
            )
            for k, v in corrs.items():
                corr_text.append(f"{k} ({v:.2f})")
        if corr_text:
            narrative.append(
                "The strongest simple numeric relationships with the target are: "
                + ", ".join(corr_text)
                + "."
            )

    missing_cols = df.isna().mean().sort_values(ascending=False)
    missing_cols = missing_cols[missing_cols > 0].head(3)
    if not missing_cols.empty:
        narrative.append(
            "The columns with the most missing data are "
            + ", ".join([f"{c} ({v*100:.1f}%)" for c, v in missing_cols.items()])
            + "."
        )

    narrative.append(
        "This app is meant as a rapid first pass. For a production-grade project, you would typically add "
        "cross-validation, feature engineering, model comparison, and clearer causal assumptions."
    )

    return "\n\n".join(narrative)


def plot_numeric_distribution(df: pd.DataFrame, column: str):
    fig, ax = plt.subplots(figsize=(8, 4))
    df[column].dropna().plot(kind="hist", bins=30, ax=ax)
    ax.set_title(f"Distribution of {column}")
    ax.set_xlabel(column)
    return fig


def plot_target_relationship(df: pd.DataFrame, x_col: str, y_col: str):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.scatter(df[x_col], df[y_col], alpha=0.6)
    ax.set_title(f"{x_col} vs {y_col}")
    ax.set_xlabel(x_col)
    ax.set_ylabel(y_col)
    return fig


st.title("PolicyPulse")
st.caption("Upload a CSV, profile the data, and generate a quick forecasting baseline.")

with st.sidebar:
    st.header("About")
    st.write(
        "A portfolio-friendly Streamlit project for public policy, economics, business, or operations datasets."
    )
    uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])


df = load_data(uploaded_file)

if df is None:
    st.info("Upload a CSV file to begin.")
    st.markdown(
        textwrap.dedent(
            """
            ### What this project shows on GitHub
            - Clean Streamlit app structure
            - Exploratory data profiling
            - Baseline predictive modeling
            - Narrative insight generation
            - Reproducible environment with requirements.txt
            """
        )
    )
    st.stop()

st.subheader("Preview")
st.dataframe(df.head(), use_container_width=True)

col1, col2, col3 = st.columns(3)
col1.metric("Rows", f"{len(df):,}")
col2.metric("Columns", len(df.columns))
col3.metric("Missing Cells", int(df.isna().sum().sum()))

st.subheader("Column Summary")
summary_df = summarize_dataframe(df)
st.dataframe(summary_df, use_container_width=True)

numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
all_cols = df.columns.tolist()

if not all_cols:
    st.warning("The uploaded dataset has no columns.")
    st.stop()

target = st.selectbox("Choose a target variable", options=all_cols)
problem_type = detect_problem_type(df[target])
st.write(f"Detected problem type: **{problem_type}**")

st.subheader("Quick Narrative")
st.write(generate_narrative(df, target, problem_type))

if numeric_cols:
    st.subheader("Visualization")
    viz_col = st.selectbox("Choose a numeric column to visualize", options=numeric_cols)
    st.pyplot(plot_numeric_distribution(df, viz_col))

    if target in numeric_cols and viz_col != target:
        st.pyplot(plot_target_relationship(df, viz_col, target))

feature_options = [c for c in all_cols if c != target]
if not feature_options:
    st.warning("You need at least one feature column besides the target.")
    st.stop()

selected_features = st.multiselect(
    "Choose feature columns",
    options=feature_options,
    default=feature_options[: min(5, len(feature_options))],
)

if len(selected_features) == 0:
    st.warning("Please choose at least one feature column.")
    st.stop()

model_df = df[selected_features + [target]].copy()
X = model_df[selected_features]
y = model_df[target]

try:
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    pipeline = build_model(X, y, problem_type)
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_test)

    st.subheader("Model Results")
    if problem_type == "regression":
        rmse = float(np.sqrt(mean_squared_error(y_test, preds)))
        mae = float(mean_absolute_error(y_test, preds))
        r2 = float(r2_score(y_test, preds))

        m1, m2, m3 = st.columns(3)
        m1.metric("RMSE", f"{rmse:.3f}")
        m2.metric("MAE", f"{mae:.3f}")
        m3.metric("R²", f"{r2:.3f}")

        results = pd.DataFrame({"actual": y_test, "predicted": preds}).reset_index(drop=True)
        st.dataframe(results.head(20), use_container_width=True)
    else:
        acc = float(accuracy_score(y_test, preds))
        st.metric("Accuracy", f"{acc:.3f}")
        results = pd.DataFrame({"actual": y_test.astype(str), "predicted": preds.astype(str)}).reset_index(drop=True)
        st.dataframe(results.head(20), use_container_width=True)

except Exception as e:
    st.error(f"Modeling failed: {e}")

st.subheader("Download Cleaned Summary")
summary_csv = summary_df.to_csv(index=False).encode("utf-8")
st.download_button(
    label="Download column summary",
    data=summary_csv,
    file_name="column_summary.csv",
    mime="text/csv",
)
